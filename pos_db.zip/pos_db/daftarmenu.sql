-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 11:12 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftarmenu`
--

CREATE TABLE `daftarmenu` (
  `idMenu` bigint(20) UNSIGNED NOT NULL,
  `namaMenu` varchar(255) NOT NULL,
  `hargaMenu` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `daftarmenu`
--

INSERT INTO `daftarmenu` (`idMenu`, `namaMenu`, `hargaMenu`, `gambar`, `created_at`, `updated_at`) VALUES
(5, 'Ikan Bakar', 50000, 'KnwcGdnTykwCBdP2JMH6m1ofZMqINxcMSXlFdSEo.jpg', '2024-04-28 01:10:25', '2024-04-28 01:10:25'),
(6, 'Gulai Ikan Kakap', 35000, 'B3e5iBb89gvl7mUSt9R6CNkMs3RJt3lOwa4YBPiy.jpg', '2024-04-28 01:10:55', '2024-04-28 01:10:55'),
(7, 'Ikan Goreng', 35000, 'ymaUTrRYH3ZziyenJkLvtFPav5WREiJSa0JbdsPm.jpg', '2024-04-28 01:11:48', '2024-04-28 01:11:48'),
(8, 'Ayam Bakar', 20000, 'tpCFGvWMzLY0UYpLTHctGwpGMKyP5ivKFZf95Ouo.jpg', '2024-04-28 01:12:09', '2024-04-28 01:12:09'),
(9, 'Ayam Kecap', 20000, 'rwQeOGUVOrMsIOvLgLoWQmjyYF8FMlNAlKLq0hA1.jpg', '2024-04-28 01:12:27', '2024-04-28 01:12:27'),
(10, 'Ayam Suwir', 25000, 'XofVY63yDaDtsFvN3qu0iOvNtYNPlGPl359zaPxv.jpg', '2024-04-28 01:13:24', '2024-04-28 01:13:24'),
(11, 'Flank Steak', 150000, 'VLsPqKx3WwMiRBsfiBho7VsWTmu45zGP0Eh8mT9C.jpg', '2024-04-28 01:21:47', '2024-04-28 01:21:47'),
(12, 'Tomahawk Steak', 300000, 'PLrw5yUHyQmMS5MNOh2ZgZ0FCLmCGU6HmfHDAD9q.jpg', '2024-04-28 01:22:10', '2024-04-28 01:22:10'),
(13, 'Wagyu a5 Steak', 1000000, 'yz5KVWwLKuSKuLDkeVgFGawwTM9vf7mph1LJfuJD.jpg', '2024-04-28 01:22:28', '2024-04-28 01:22:28'),
(14, 'Sate Ayam', 20000, '5D7uGw5wndefQjSBMf0UDlpGYNGiRerXAYoEZ2Iu.jpg', '2024-04-28 01:22:57', '2024-04-28 01:22:57'),
(15, 'Sate Kambing', 35000, 'QDxLrcWY3ieXKdyNaix00OsWIDKc2FxBRRdOpOHe.jpg', '2024-04-28 01:23:20', '2024-04-28 01:23:20'),
(16, 'Nasi Putih', 5000, 'l4hpIqXojBfy6uYbL2h2g8VZ0Le6NTmtaje9glWP.jpg', '2024-04-28 01:23:47', '2024-04-28 01:23:47'),
(17, 'Es Teh Manis', 8000, 'r8SdAA9Esum59KJoxQkxvEnUZGONwtHDnLtfRBMY.jpg', '2024-04-28 01:24:08', '2024-04-28 01:24:08'),
(18, 'Es Jeruk', 15000, 'PKqiVYWNSp2lipOab1MhGIrdXLKkHzMUFUnI0yLW.jpg', '2024-04-28 01:24:22', '2024-04-28 01:24:22'),
(19, 'Air Mineral', 5000, 'Pz3pwZz6MbcH0l65SKQJ3uLG504brJck5l2TDQkQ.jpg', '2024-04-28 01:24:50', '2024-04-28 01:24:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftarmenu`
--
ALTER TABLE `daftarmenu`
  ADD PRIMARY KEY (`idMenu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftarmenu`
--
ALTER TABLE `daftarmenu`
  MODIFY `idMenu` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
